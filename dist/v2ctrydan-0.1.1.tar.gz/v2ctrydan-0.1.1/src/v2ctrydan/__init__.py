"""Init for v2ctrydan library."""
